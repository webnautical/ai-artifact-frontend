export const TABLE_ROW_PER_PAGE = 10
export const TABLE_PAGINATION_DROPDOWN = [10,20,30,40,50]
export const SOMETHING_ERR="Something wen't wrong"
export const SERVER_ERR="Server Error - Try Again"
// export const GOOGLE_CLIENT_ID = "1035956082295-mvham52q68fpkni0jkimv1iacb6lu68t.apps.googleusercontent.com"
export const GOOGLE_CLIENT_ID = "502598940486-jrl0kphco8j1ok2s98fcdha5h4dt55u8.apps.googleusercontent.com"
export const FB_APP_ID = "1143179496737523"

export const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export const strongPasswordPattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&!@#$%^&*()_+[\]{}|;:,.<>/?])[A-Za-z\d@$!%*?&!@#$%^&*()_+[\]{}|;:,.<>/?]{8,}$/;

export const P_UID = "flat_130x180-mm-5r_200-gsm-80lb-uncoated_4-0_ver"
export const UID_OBJ = {"quality": "Matte","frame": "No Frame","size": "13x18 cm / 5x7\""}