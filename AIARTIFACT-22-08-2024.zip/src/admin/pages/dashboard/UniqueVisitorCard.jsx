

import IncomeAreaChart from './IncomeAreaChart';


export default function UniqueVisitorCard() {
  return (
    <>
      <IncomeAreaChart  />
    </>
  );
}
