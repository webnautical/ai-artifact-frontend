import { Outlet } from 'react-router-dom';
// import '../../../assets/css/admin.css'
export default function MinimalLayout() {
  return (
    <>
      <Outlet />
    </>
  );
}
